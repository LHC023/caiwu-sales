#!/usr/bin/env python3
"""把两张收款码 base64 内联进 sales/index.template.html，产出可单独托管的 sales/index.html。

用法（在包根目录执行）：
    python sales/build_sales.py
换码后重跑即可；输出为自包含单文件，可直接丢进 GitHub Pages。
构建最后一步会断言公开页不含许可方真实姓名。
"""
import base64
import pathlib
import re
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
TEMPLATE = ROOT / "sales" / "index.template.html"
OUT = ROOT / "sales" / "index.html"
RELEASE_URL = "https://github.com/LHC023/caiwu-sales/releases/latest"


def private_names() -> list[str]:
    """从包内 LICENSE.md 反查许可方真实姓名——脚本本身不硬编码，避免多处复制。"""
    license_text = (ROOT / "LICENSE.md").read_text(encoding="utf-8")
    found = re.findall(r"许可方（可追责主体）\*\*：([^\s（]+)", license_text)
    return [n for n in found if len(n) >= 2]


def b64(path: pathlib.Path) -> str:
    return base64.b64encode(path.read_bytes()).decode("ascii")


def main() -> int:
    version = (ROOT / "VERSION").read_text(encoding="utf-8").strip()
    html = TEMPLATE.read_text(encoding="utf-8")
    html = html.replace("{{VERSION}}", version)
    html = html.replace("{{RELEASE_URL}}", RELEASE_URL)
    html = html.replace("{{WX_QR}}", b64(ROOT / "payment" / "qr.png"))
    html = html.replace("{{ALI_QR}}", b64(ROOT / "payment" / "alipay-qr.jpg"))

    if "{{" in html:
        raise SystemExit("FAIL: 模板仍有未替换的占位符")
    leaks = [n for n in private_names() if n in html]
    if leaks:
        raise SystemExit(f"FAIL: 公开页出现许可方真实姓名 {leaks}")
    if not private_names():
        raise SystemExit("FAIL: 未能从 LICENSE.md 定位可追责主体，泄露检查失效")

    OUT.write_text(html, encoding="utf-8")
    print(f"OK  {OUT}  {OUT.stat().st_size:,} bytes  (v{version})")
    return 0


if __name__ == "__main__":
    sys.exit(main())
