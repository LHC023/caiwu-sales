---
name: 量表知识库
version: 1.0.0
description: Internal SSOT for the finance suite - KPI table (ratified weights), numbering anchors, deliverable schema, scoring parameters, loop contracts. Hidden from menu. Weights ratified by owner.
description_zh: 财务部套件的内部唯一事实来源：KPI 总表(核定权重)、条款编号锚点、交付件Schema、考核参数、协同闭环契约。供各 Agent 引用，不在菜单显示。权重已核定。
user-invocable: false
status: active
---

# 财务部 知识库（内部·唯一事实来源）

本库是整套财务部 Agent 的事实来源；职责条款/KPI/扣分/交付件字段/阈值/闭环均以此为准，分部不得自行编造。
权重与条款已经财务负责人核定为正式执行值（v1.0.0，2026-10-04），各 SKILL `status: official`。岗位骨架来源：已装「企业财税」套件能力域。

## 使用方式
- 职责原文 + KPI 权重 → [岗位与KPI总表](references/岗位与KPI总表.md)（各岗合计=100%）
- 带圈编号互引 → [条款编号锚点表](references/条款编号锚点表.md)（禁引表外编号）
- 交付件字段与拒收 → [交付件Schema](references/交付件Schema.md)
- 扣分/阈值/时限/状态 → [考核参数表](references/考核参数表.md)（按参数 ID）
- 跨 Agent 循环 → [协同闭环契约](references/协同闭环契约.md)（L1–L5）

## 可审计五原则
1. 唯一事实来源+编号锚点成对；2. 交付物即契约(字段级+reject-if)；3. 状态机器可读(frontmatter `status`)；4. 闭环四要素齐备；5. 阈值配置化(参数 ID)。

## 与「企业财税」技能的关系
各分部是"管理+考核+契约"壳，实际专业动作复用已装 `corporate-finance-tax` 技能（做凭证/月结检查清单/增值税管理/汇算清缴/财务报表编制/财务分析/预算分析/内部审计）。分部负责按其字段契约产出、走闭环、算考核，专业计算交给财税技能。
